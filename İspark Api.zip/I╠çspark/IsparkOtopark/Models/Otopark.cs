﻿using System;
namespace IsparkOtopark.Models
{
	public class Otopark
	{
		public int parkID { get; set; }
		public string parkName { get; set; }
		public string lat { get; set; }
		public string lng { get; set; }
		public int capacity { get; set; }
		public int emptyCapacity { get; set; }
		public string workHours { get; set; }
		public string parkType { get; set; }
		public int freeTime { get; set; }
		public string district { get; set; }
		public int isOpen { get; set; }

	}
}

